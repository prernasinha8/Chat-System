<?php
$host="localhost";
$db_name="chat";
$user="root";
$pass="";

			$con = new mysqli($host,$user,$pass,$db_name);
			function formatDate($date)
			{
				return date('g:i a',strtotime($date));
			}
			
?>