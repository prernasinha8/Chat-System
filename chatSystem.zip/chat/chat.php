<?php

include 'db.php';
$query = "SELECT *FROM chat ORDER BY  id DESC";
		$run = $con->query($query);
		while($row = $run-> fetch_array()):

?>

<div id="chat_data">
<span style= "color:green;"><?php echo $row['name'];?></span>:
<span Style= "color:red;"><?php echo $row['message'];?></span>
<span Style= "float:right;"><?php echo formatdate($row['date']);?></span>
</div>
<?php endwhile; ?>
